Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - Kyster ( https://freesound.org/people/Kyster/ )

You can find this pack online at: https://freesound.org/people/Kyster/packs/7398/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 117852__Kyster__2_oct_c.wav
    * url: https://freesound.org/s/117852/
    * license: Attribution
  * 117720__Kyster__Low_D.wav
    * url: https://freesound.org/s/117720/
    * license: Attribution
  * 117719__Kyster__Low_D_.wav
    * url: https://freesound.org/s/117719/
    * license: Attribution
  * 117718__Kyster__G.wav
    * url: https://freesound.org/s/117718/
    * license: Attribution
  * 117717__Kyster__G_.wav
    * url: https://freesound.org/s/117717/
    * license: Attribution
  * 117716__Kyster__F.wav
    * url: https://freesound.org/s/117716/
    * license: Attribution
  * 117715__Kyster__F_.wav
    * url: https://freesound.org/s/117715/
    * license: Attribution
  * 117714__Kyster__E.wav
    * url: https://freesound.org/s/117714/
    * license: Attribution
  * 117713__Kyster__D.wav
    * url: https://freesound.org/s/117713/
    * license: Attribution
  * 117712__Kyster__D_.wav
    * url: https://freesound.org/s/117712/
    * license: Attribution
  * 117711__Kyster__C.wav
    * url: https://freesound.org/s/117711/
    * license: Attribution
  * 117710__Kyster__C_.wav
    * url: https://freesound.org/s/117710/
    * license: Attribution
  * 117709__Kyster__B.wav
    * url: https://freesound.org/s/117709/
    * license: Attribution
  * 117708__Kyster__A.wav
    * url: https://freesound.org/s/117708/
    * license: Attribution
  * 117707__Kyster__A_.wav
    * url: https://freesound.org/s/117707/
    * license: Attribution
  * 117706__Kyster__3_oct_e.wav
    * url: https://freesound.org/s/117706/
    * license: Attribution
  * 117705__Kyster__2_oct_g.wav
    * url: https://freesound.org/s/117705/
    * license: Attribution
  * 117704__Kyster__2_oct_g_.wav
    * url: https://freesound.org/s/117704/
    * license: Attribution
  * 117703__Kyster__2_oct_f.wav
    * url: https://freesound.org/s/117703/
    * license: Attribution
  * 117702__Kyster__2_oct_f_.wav
    * url: https://freesound.org/s/117702/
    * license: Attribution
  * 117701__Kyster__2_oct_e.wav
    * url: https://freesound.org/s/117701/
    * license: Attribution
  * 117700__Kyster__2_oct_d.wav
    * url: https://freesound.org/s/117700/
    * license: Attribution
  * 117699__Kyster__2_oct_d_.wav
    * url: https://freesound.org/s/117699/
    * license: Attribution
  * 117697__Kyster__2_oct_c_.wav
    * url: https://freesound.org/s/117697/
    * license: Attribution
  * 117696__Kyster__2_oct_b.wav
    * url: https://freesound.org/s/117696/
    * license: Attribution
  * 117695__Kyster__2_oct_a.wav
    * url: https://freesound.org/s/117695/
    * license: Attribution
  * 117694__Kyster__2_oct_a_.wav
    * url: https://freesound.org/s/117694/
    * license: Attribution
  * 117693__Kyster__1_oct_g.wav
    * url: https://freesound.org/s/117693/
    * license: Attribution
  * 117692__Kyster__1_oct_g_.wav
    * url: https://freesound.org/s/117692/
    * license: Attribution
  * 117691__Kyster__1_oct_f.wav
    * url: https://freesound.org/s/117691/
    * license: Attribution
  * 117690__Kyster__1_oct_f_.wav
    * url: https://freesound.org/s/117690/
    * license: Attribution
  * 117689__Kyster__1_oct_e.wav
    * url: https://freesound.org/s/117689/
    * license: Attribution
  * 117688__Kyster__1_oct_d.wav
    * url: https://freesound.org/s/117688/
    * license: Attribution
  * 117687__Kyster__1_oct_d_.wav
    * url: https://freesound.org/s/117687/
    * license: Attribution
  * 117686__Kyster__1_oct_c.wav
    * url: https://freesound.org/s/117686/
    * license: Attribution
  * 117685__Kyster__1_oct_c_.wav
    * url: https://freesound.org/s/117685/
    * license: Attribution
  * 117684__Kyster__1_oct_b.wav
    * url: https://freesound.org/s/117684/
    * license: Attribution
  * 117683__Kyster__1_oct_a.wav
    * url: https://freesound.org/s/117683/
    * license: Attribution
  * 117682__Kyster__1_oct_a_.wav
    * url: https://freesound.org/s/117682/
    * license: Attribution


